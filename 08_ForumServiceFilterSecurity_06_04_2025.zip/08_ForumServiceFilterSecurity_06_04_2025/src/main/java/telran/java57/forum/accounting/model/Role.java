package telran.java57.forum.accounting.model;

public enum Role {
    USER, MODERATOR, ADMINISTRATOR;
}
