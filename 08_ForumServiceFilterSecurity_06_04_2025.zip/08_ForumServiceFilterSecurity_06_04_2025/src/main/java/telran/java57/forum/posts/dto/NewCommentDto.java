package telran.java57.forum.posts.dto;

import lombok.Getter;

@Getter
public class NewCommentDto {
    String message;
}
