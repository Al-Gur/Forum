package telran.java57.forum.accounting.dto;

import lombok.Getter;

@Getter
public class UpdateUserDto {
    String firstName;
    String lastName;
}
